Component({
  data: {},
  properties: {},
  methods: {}
})